
const AdvancedSearch = () => {
    return (
        <div>
            This is advanced search
        </div>
    );
};

export default AdvancedSearch;