
const Home = () => {
    return (
        <div>
            this is home page
        </div>
    );
};

export default Home;