
const News = () => {
    return (
        <div>
            This is about page
        </div>
    );
};

export default News;